package MyPackage;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import MyPackage2.Screenshots;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import io.github.bonigarcia.wdm.WebDriverManager;

public class lab6 {
	static WebDriver driver; 
	static Logger logger = Logger.getLogger("lab6");
	
	@Test
	public void test1()
	{
		PropertyConfigurator.configure("Log4j.properties");
		WebDriverManager.edgedriver().setup();
		EdgeOptions options = new EdgeOptions();
		options.addArguments("--remote-allow-origins-");
		driver = new EdgeDriver(options);
		String BaseURL = "https://www.globalsqa.com/angularJs-protractor/BankingProject";
		driver.get(BaseURL); 
		logger.info("The entered URL has been succesfully opened.");
		driver.manage().window().maximize();
		//System.out.println("Test 1 has passed!");
	}
	@AfterMethod
	public void Aftermethod0 (ITestResult result)throws IOException {
		if (ITestResult.FAILURE==result.getStatus()) {
			Screenshots.TakingScreenshot(driver, result.getName());
		}
	}
	
	
	@Test(priority=1, groups= {"Manager Operations"})
	public void test2()
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//button[contains(@ng-click,'man')]")));
		WebElement Manager_Button = driver.findElement(By.xpath("//button[contains(@ng-click,'man')]"));
		Manager_Button.click();
		logger.info("The Manager has successfully logged in.");
		//System.out.println("Test 2 has passed!");
	}
	@AfterMethod
	public void Aftermethod1 (ITestResult result)throws IOException {
		if (ITestResult.FAILURE==result.getStatus()) {
			Screenshots.TakingScreenshot(driver, result.getName());
		}
	}
//---------------------------------------------------------------------------------------------------	
	@Test(priority=2, groups= {"Manager Operations"})
	public void test3() throws InterruptedException 
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//button[contains(@ng-click,'addCust()')]")));
        WebElement Add_Customer = driver.findElement(By.xpath("//button[contains(@ng-click,'addCust()')]"));
		Add_Customer.click();
		logger.info("The manager successfully clicked on Add Customer's button.");
		//System.out.println("Test 3 has passed!");
	}
	@AfterMethod
	public void Aftermethod2 (ITestResult result)throws IOException {
		if (ITestResult.FAILURE==result.getStatus()) {
			Screenshots.TakingScreenshot(driver, result.getName());
		}
	}
//------------------------------------------------------------------------------------------------------	
	@Test(priority=3, groups= {"Manager Operations"})
	public void test4() throws InterruptedException 
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//input[contains(@ng-model,'fName')]")));
		WebElement First_Name = driver.findElement(By.xpath("//input[contains(@ng-model,'fName')]"));
		First_Name.sendKeys("Ahsan");
		WebElement Last_Name = driver.findElement(By.xpath("//input[contains(@ng-model,'lName')]"));
		Last_Name.sendKeys("Hanif");
		WebElement Postcode = driver.findElement(By.xpath("//input[contains(@ng-model,'post')]"));
		Postcode.sendKeys("54000");
		WebElement Add_Customer = driver.findElement(By.xpath("//button[text()='Add Customer']"));
		Add_Customer.click();
		driver.switchTo().alert().accept();
		logger.info("The manager has successfully entered the details of new customer.");
		//System.out.println("Test 4 has passed!");
	}	
	@AfterMethod
	public void Aftermethod3 (ITestResult result)throws IOException {
		if (ITestResult.FAILURE==result.getStatus()) {
			Screenshots.TakingScreenshot(driver, result.getName());
		}
	}
//------------------------------------------------------------------------------------------------------
	@Test(priority=4, groups= {"Manager Operations"})
	public void test5() throws Exception 
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//button[@ng-click='openAccount()']")));
        WebElement OpenAccount_Button = driver.findElement(By.xpath("//button[@ng-click='openAccount()']"));
        OpenAccount_Button.click();
        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait1.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//select[@ng-model='custId']")));
        Select Customer_drpdown = new Select(driver.findElement(By.xpath("//select[@ng-model='custId']")));
        Customer_drpdown.selectByVisibleText("Ahsan Hanif");
        Select Currency_drpdown = new Select(driver.findElement(By.xpath("//select[@ng-model='currency']")));
        Currency_drpdown.selectByVisibleText("Pound");
        WebElement Process_Button = driver.findElement(By.xpath("//button[text()='Process']"));
        Process_Button.click();
        driver.switchTo().alert().accept();
        logger.info("The manager has successfully opened the bank accoount for new customer.");
        //System.out.println("Test 5 has passed!");   
	}
	@AfterMethod
	public void Aftermethod4 (ITestResult result)throws IOException {
		if (ITestResult.FAILURE==result.getStatus()) {
			Screenshots.TakingScreenshot(driver, result.getName());
		}
	}
//------------------------------------------------------------------------------------------------------	
		@Test(priority=5, groups= {"Customer Operations"})
	public void test6() throws InterruptedException 
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//button[@ng-click='home()']")));
        WebElement Home_Button=driver.findElement(By.xpath("//button[@ng-click='home()']"));
        Home_Button.click();
        logger.info("The manager has successfully clicked on Home Button.");
        //System.out.println("Test 6 has passed!");
	}	
	@AfterMethod
	public void Aftermethod5 (ITestResult result)throws IOException {
		if (ITestResult.FAILURE==result.getStatus()) {
			Screenshots.TakingScreenshot(driver, result.getName());
		}
	}
//------------------------------------------------------------------------------------------------------	
	@Test(priority=6, groups= {"Customer Operations"})
	public void test7() throws InterruptedException 
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//button[@ng-click='customer()']")));
        WebElement CustomerLogin_Button=driver.findElement(By.xpath("//button[@ng-click='customer()']"));
        CustomerLogin_Button.click();
        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait1.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[text()='Your Name :']//following::select")));
        Select Your_Name = new Select(driver.findElement(By.xpath("//label[text()='Your Name :']//following::select")));
        Your_Name.selectByVisibleText("Ahsan Hanif");
        WebElement Login_Button = driver.findElement(By.xpath("//button[text()='Login']"));
        Login_Button.click();
        logger.info("The Customer has successfully logged in and searched his/her name.");
        //System.out.println("Test 7 has passed!");
	}	
	@AfterMethod
	public void Aftermethod6 (ITestResult result)throws IOException {
		if (ITestResult.FAILURE==result.getStatus()) {
			Screenshots.TakingScreenshot(driver, result.getName());
		}
	}
//------------------------------------------------------------------------------------------------------	
	@Test(priority=7, groups= {"Customer Operations"})
	public void test8() throws InterruptedException 
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//button[@ng-click='deposit()']")));
     	WebElement Deposit = driver.findElement(By.xpath("//button[@ng-click='deposit()']"));
     	Deposit.click();
     	WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait1.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[text()='Amount to be Deposited :']//following::input")));
     	WebElement Amount_Deposited=driver.findElement(By.xpath("//label[text()='Amount to be Deposited :']//following::input"));
     	Amount_Deposited.sendKeys("10000");
     	WebElement DepositAmount_Button = driver.findElement(By.xpath("//button[text()='Deposit']"));
     	DepositAmount_Button.click();
     	logger.info("The customer has successfully deposited the desried amount.");
     	//System.out.println("Test 8 has passed!");
	}
	@AfterMethod
	public void Aftermethod7 (ITestResult result)throws IOException {
		if (ITestResult.FAILURE==result.getStatus()) {
			Screenshots.TakingScreenshot(driver, result.getName());
		}
	}
//------------------------------------------------------------------------------------------------------	
	@Test(priority=8, groups= {"Customer Operations"})
	public void test9() throws InterruptedException 
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//button[@ng-click='withdrawl()']")));
        WebElement Withdrawl_Button =driver.findElement(By.xpath("//button[@ng-click='withdrawl()']"));
        Withdrawl_Button.click();
        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait1.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//label[text()='Amount to be Withdrawn :']//following::input")));
     	WebElement Amount_Withdrawn=driver.findElement(By.xpath("//label[text()='Amount to be Withdrawn :']//following::input"));
     	Amount_Withdrawn.sendKeys("2000");
     	WebElement WithdrawAmount_Button = driver.findElement(By.xpath("//button[text()='Withdraw']"));
     	WithdrawAmount_Button.click();
     	logger.info("The customer has successfully withdrawn required amount.");
     	//ystem.out.println("Test 9 has passed!");
	}
	@AfterMethod
	public void Aftermethod8 (ITestResult result)throws IOException {
		if (ITestResult.FAILURE==result.getStatus()) {
			Screenshots.TakingScreenshot(driver, result.getName());
		}
	}
//------------------------------------------------------------------------------------------------------ 
	@Test(priority=9, groups= {"Customer Operations"})
	public void test10() throws InterruptedException 
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//button[@ng-click='transactions()']")));
        WebElement Transactions_Button = driver.findElement(By.xpath("//button[@ng-click='transactions()']"));
        Transactions_Button.click();
        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait1.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//button[@ng-click='back()']")));
        driver.findElement(By.xpath("//button[@ng-click='back()']")).click();
        Thread.sleep(10);
        WebDriverWait wait2 = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait2.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//button[@ng-click='transactions()']")));
        WebElement Transactions_Button1 = driver.findElement(By.xpath("//button[@ng-click='transactions()']"));
        Transactions_Button1.click();
        List<WebElement> listoftable = driver.findElements(By.xpath("//table[@class='table table-bordered table-striped']"));
        for (WebElement eachlink : listoftable) {
        	System.out.println(eachlink.getText());
        }
        logger.info("The customer has successfully viewed and printed his/her transaction history.");
     	//System.out.println("Test 10 has passed!");
	}
	@AfterMethod
	public void Aftermethod9 (ITestResult result)throws IOException {
		if (ITestResult.FAILURE==result.getStatus()) {
			Screenshots.TakingScreenshot(driver, result.getName());
		}
	}
//------------------------------------------------------------------------------------------------------
	@Test(priority=10, groups= {"Customer Operations"})
	public void test11() throws InterruptedException 
	{
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//button[@ng-click='reset()']")));
	    WebElement Reset_Button = driver.findElement(By.xpath("//button[@ng-click='reset()']"));
	    Reset_Button.click();
	    WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait1.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//button[@ng-click='home()']")));
        WebElement Home_Button=driver.findElement(By.xpath("//button[@ng-click='home()']"));
        Home_Button.click();
        logger.info("The Customer has reset the transaction history and retured to HOME.");
        //System.out.println("Test 11 has passed!");
	}
	@AfterMethod
	public void Aftermethod10 (ITestResult result)throws IOException {
		if (ITestResult.FAILURE==result.getStatus()) {
			Screenshots.TakingScreenshot(driver, result.getName());
		}
	}
//------------------------------------------------------------------------------------------------------
	@Test(priority=11, groups= {"Manager Operations"})
	public void test12() throws InterruptedException 
	{
		WebElement Manager_Button = driver.findElement(By.xpath("//button[contains(@ng-click,'man')]"));
		Manager_Button.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//button[@ng-click='showCust()']")));
        WebElement Customers_Button=driver.findElement(By.xpath("//button[@ng-click='showCust()']"));
        Customers_Button.click();
        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait1.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//input[@ng-model='searchCustomer']")));
        WebElement Search =driver.findElement(By.xpath("//input[@ng-model='searchCustomer']"));
        Search.click();
        Search.sendKeys("Ah");
        WebElement Delete_Customer =driver.findElement(By.xpath("//button[@ng-click='deleteCust(cust)']"));
        Delete_Customer.click();
        WebElement Home_Button=driver.findElement(By.xpath("//button[@ng-click='home()']"));
        Home_Button.click();
        logger.info("The manager has successfully deleted the bank account and returned to HOME.");
        //System.out.println("Test 12 has passed!");
	}
	@AfterMethod
	public void Aftermethod11 (ITestResult result)throws IOException {
		if (ITestResult.FAILURE==result.getStatus()) {
			Screenshots.TakingScreenshot(driver, result.getName());
		}
	}
//------------------------------------------------------------------------------------------------------
}
