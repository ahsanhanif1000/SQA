package MyPackage;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Lab3 {
	static WebDriver driver;
	public static void main(String[] args) {
	WebDriverManager.edgedriver().setup();
	EdgeOptions options = new EdgeOptions();
	options.addArguments("--remote-allow-origins-");
	driver = new EdgeDriver(options);
    String BaseURL = "https://omayo.blogspot.in/";
	driver.get(BaseURL); 
				
	WebElement TextBox1 = driver.findElement(By.xpath("//*[@id=\"ta1\"or@contentditable=\"true\"]"));
	TextBox1.clear();
	TextBox1.sendKeys("KING");
	String input = TextBox1.getAttribute("value");
	String ER = "KING";
				
				if (input.equals(ER)) {
					System.out.println("Your 1st test has passed.");
				}
					else {
						System.out.println("Your 1st test has failed");
					}
		        System.out.println("------------------------------------------------- ");
	// Getting the elements of Table
	String Table = driver.findElement(By.xpath("//*[contains(@id,'tab')]")).getText();
    System.out.println(Table);
	System.out.println("------------------------------------------------- ");
						 
	// Entering Username and Password and Clicking Login Button
	WebElement Username = driver.findElement(By.xpath("//form[contains(name,'')]//input[1]"));
	Username.clear();
	Username.sendKeys("ahsanhanif207@gmail.com");
	String input2 = Username.getAttribute("value");
	String ER2 = "ahsanhanif207@gmail.com";
					if (input2.equals(ER2)) {
						System.out.println("Your 2nd test has passed.");
					}
					   else {
						   System.out.println("Your 2nd test has failed");
					   }
					System.out.println("------------------------------------------------- ");	
	WebElement Password = driver.findElement(By.xpath("//form[contains(name,'')]//input[2]"));
	Password.clear();
	Password.sendKeys("King1234*");
	String input3 = Password.getAttribute("value");
	String ER3 = "King1234*";
					if (input3.equals(ER3)) {
						System.out.println("Your 3rd test has passed.");
					}
					   else {
						   System.out.println("Your 3rd test has failed");
					   }
					System.out.println("------------------------------------------------- ");
	//----------------------------------------------------------------------
					WebElement Username1 = driver.findElement(By.xpath("//input[@name='userid']"));
					Username1.clear();
					Username1.sendKeys("ahsanhanif207@gmail.com");
					String input_2 = Username1.getAttribute("value");
					String ER_2 = "ahsanhanif207@gmail.com";
									if (input_2.equals(ER_2)) {
										System.out.println("Your 4th test has passed.");
									}
									   else {
										   System.out.println("Your 4th test has failed");
									   }
									System.out.println("------------------------------------------------- ");	
					WebElement Password1 = driver.findElement(By.xpath("//input[@name='pswrd']"));
					Password1.clear();
					Password1.sendKeys("King1234*");
					String input_3 = Password1.getAttribute("value");
					String ER_3 = "King1234*";
									if (input_3.equals(ER_3)) {
										System.out.println("Your 5th test has passed.");
									}
									   else {
										   System.out.println("Your 5th test has failed");
									   }
									System.out.println("------------------------------------------------- ");
													
					
    //-----------------------------------------------------------------------
	WebElement Hyundai = driver.findElement(By.xpath("//option[contains(@value,'Hyun')]"));
	Hyundai.click();
					
	Select drpdocs = new Select(driver.findElement(By.xpath("//select[contains(@name,'Site')]")));
	drpdocs.selectByVisibleText("doc 3");
	
	WebElement TextBox2 = driver.findElement(By.xpath("//input[contains(@name,'fname')]"));
	TextBox2.clear();
	TextBox2.sendKeys("Hello");
	System.out.println("------------------------------------------------- ");
	
	WebElement Button2 = driver.findElement(By.xpath("//button[contains(@contenteditable,'true')]"));
	Button2.click();
	
	java.util.List<WebElement> buttons = driver.findElements(By.name("samename"));
	for (WebElement button : buttons) {
		button.click();
	}
	
	WebElement Button3 = driver.findElement(By.xpath("//input[contains(@value,'ClickAfter')]"));
	Button3.click();
	String AlertText= driver.switchTo().alert().getText();
	System.out.println(AlertText);
	driver.switchTo().alert().accept();
	
	WebElement PopupWindow = driver.findElement(By.linkText("Open a popup window"));
	PopupWindow.click();
	
	Set<String> handles= driver.getWindowHandles();
	Iterator<String> it=handles.iterator();
	String parentid = (String)it.next();
	String childid = (String)it.next();
	driver.switchTo().window(childid);
	WebElement Error = driver.findElement(By.xpath("/html/body"));
	Error.getText();
	String Error404 = Error.getText();
	System.out.println(Error404);
	driver.close();
	
	driver.switchTo().window(parentid);
	
	WebElement Gender = driver.findElement(By.xpath("//input[@value='male']"));
	Gender.click();
	
	WebElement Alert2 = driver.findElement(By.xpath("//input[@value='ClickToGetAlert']"));
	Alert2.click();
	String Alert= driver.switchTo().alert().getText();
	System.out.println(Alert);
	driver.switchTo().alert().accept();
	
	WebElement Orange = driver.findElement(By.xpath("//input[@value='orange']"));
	Orange.click();
	WebElement Blue = driver.findElement(By.xpath("//input[@value='blue']"));
	Blue.click();
	
	WebElement ReadThisText = driver.findElement(By.xpath("//input[@id='rotb']"));
	ReadThisText.getAttribute("value");
	String Readthistext = ReadThisText.getAttribute("value");
	System.out.println(Readthistext);
	
	WebElement Prompt = driver.findElement(By.xpath("//input[@value='GetPrompt']"));
	Prompt.click();
	String Alert_3 = driver.switchTo().alert().getText();
	System.out.println(Alert_3);
	Alert alert = driver.switchTo().alert();
	alert.sendKeys("Ahsan Hanif");
	alert.accept();
	
	WebElement Confirm = driver.findElement(By.xpath("//input[@value='GetConfirmation']"));
	Confirm.click();
	String Alert_4 = driver.switchTo().alert().getText();
	System.out.println(Alert_4);
	driver.switchTo().alert().accept();
	
	WebElement TBL1 = driver.findElement(By.xpath("//*[text()='Locate using class']//following::input"));
	TBL1.sendKeys("Ahsan");
	WebElement TBL2 = driver.findElement(By.xpath("//*[text()='element having same class name of above field']//following::input"));
	TBL2.sendKeys("Hanif");
	
	WebElement Car = driver.findElement(By.xpath("//input[@value='Car']"));
	Car.click();
	
	WebElement Bag = driver.findElement(By.xpath("//input[@value='Bag']"));
	Bag.click();
	WebElement Book = driver.findElement(By.xpath("//input[@value='Book']"));
	Book.click();
	}

		}

