package MyPackage;

import java.util.Scanner;

public class Question_03 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.print("Enter your full name: ");
	        String fullName = readLineFromConsole(scanner);

	        String abbreviation = generateAbbreviation(fullName);
	        System.out.println("Abbreviation: " + abbreviation);

	        scanner.close();
	    }

	    public static String readLineFromConsole(Scanner scanner) {
	        StringBuilder sb = new StringBuilder();
	        try {
	            char c;
	            while (true) {
	                c = (char) System.in.read();
	                if (c == '\n' || c == '\r') {
	                    break;
	                }
	                sb.append(c);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return sb.toString();
	    }

	    public static String generateAbbreviation(String fullName) {
	        int spaceIndex1 = fullName.indexOf(' ');
	        int spaceIndex2 = fullName.lastIndexOf(' ');

	        if (spaceIndex1 == -1) {
	            return fullName; // No space found, return the full name as is
	        }

	        char firstInitial = fullName.charAt(0);
	        char middleInitial = (spaceIndex1 != spaceIndex2) ? fullName.charAt(spaceIndex1 + 1) : '\0';
	        String lastName = fullName.substring(spaceIndex2 + 1);

	        return Character.toUpperCase(firstInitial) + "." + Character.toUpperCase(middleInitial) + "." + lastName;
	    }
	}

