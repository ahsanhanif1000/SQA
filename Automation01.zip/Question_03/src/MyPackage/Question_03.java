package MyPackage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Question_03 {

	public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        System.out.print("Enter a string of alphabets: ");
        String input = readLineFromConsole(reader);

        int[] alphabetCount = new int[26]; // Array to store alphabet occurrences

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c >= 'a' && c <= 'z') {
                int index = c - 'a'; // Convert character to index (0 to 25)
                alphabetCount[index]++; // Increment the count for the corresponding alphabet
            }
        }

        int maxOccurrences = -1;
        char maxChar = ' ';

        for (int i = 0; i < 26; i++) {
            if (alphabetCount[i] > maxOccurrences) {
                maxOccurrences = alphabetCount[i];
                maxChar = (char) (i + 'a'); // Convert index back to character
            }
        }

        System.out.println("Occurrences of each alphabet:");
        for (int i = 0; i < 26; i++) {
            char currentChar = (char) (i + 'a');
            System.out.println(currentChar + ": " + alphabetCount[i]);
        }

        System.out.println("Alphabet with maximum occurrence: " + maxChar);

        try {
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String readLineFromConsole(BufferedReader reader) {
        StringBuilder sb = new StringBuilder();
        try {
            int c;
            while ((c = reader.read()) != -1 && c != '\n' && c != '\r') {
                sb.append((char) c);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
}
