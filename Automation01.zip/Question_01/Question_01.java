package MyPackage;

public class Question_01 {
	    public static void main(String[] args) {
	        int min = 1; // Define the minimum range for the random number
	        int max = 100; // Define the maximum range for the random number

	        int randomNumber = generateRandomNumber(min, max); // Generate a random number within the specified range
	        int userGuess; // Variable to store the user's guess

	        System.out.println("Welcome to the Guessing Game!");
	        System.out.println("Try to guess the number between " + min + " and " + max);

	       
	            System.out.println("Enter your guess: ");
	            userGuess = readIntFromConsole(); // Read the user's guess from the console
	            

	            if (userGuess > randomNumber) {
	                System.out.println("The number is too large");
	            } else if (userGuess < randomNumber) {
	                System.out.println("The number is too small");
	            } else {
	                System.out.println("Correct Number!");}
	            
	            System.out.println("The random number, generated, was "+ randomNumber);
	            }
	            
	       
	      

	    // Function to generate a random number within a given range
	    public static int generateRandomNumber(int min, int max) {
	        // Custom random number generator using system time
	        long currentTime = System.currentTimeMillis();
	        long seed = currentTime % (max - min + 1) + min;
	        return (int) seed;
	    }
	

	    // Function to read an integer from the console
	    public static int readIntFromConsole() {
	        int result = 0;
	        boolean isNegative = false;

	        try {
	            while (true) {
	                char c = (char) System.in.read();
	                if (c == '-') {
	                    isNegative = true;
	                } else if (c >= '0' && c <= '9') {
	                    result = result * 10 + (c - '0');
	                } else if (c == '\n' || c == '\r') {
	                    break;
	                }
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }

	        return isNegative ? -result : result;
	    }
	}
